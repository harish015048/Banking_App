using Banking_Application.Repositories;

namespace Banking_Application_Tests
{
    [TestClass]
    public class RepositoryTests
    {
        [TestMethod]
        public async Task AddAccountAsync_ValidAccount_ReturnsNewAccount()
        {
            // Arrange
            var repository = new Repository();
            var user = await repository.AddUserAsync("TestUser");

            // Act
            var newAccount = await repository.AddAccountAsync(user.UserId, 200);

            // Assert
            Assert.IsNotNull(newAccount);
            Assert.AreEqual(200, newAccount.Balance);
        }

        [TestMethod]
        public async Task AddAccountAsync_InvalidInitialBalance_ThrowsArgumentException()
        {
            // Arrange
            var repository = new Repository();
            var user = await repository.AddUserAsync("TestUser");

            // Act and Assert
            await Assert.ThrowsExceptionAsync<ArgumentException>(() => repository.AddAccountAsync(user.UserId, 50));
        }

        [TestMethod]
        public async Task DeleteAccountAsync_ExistingAccount_ReturnsTrue()
        {
            // Arrange
            var repository = new Repository();
            var user = await repository.AddUserAsync("TestUser");
            var account = await repository.AddAccountAsync(user.UserId, 200);

            // Act
            var result = await repository.DeleteAccountAsync(user.UserId, account.AccountId);

            // Assert
            Assert.IsTrue(result);
        }

        [TestMethod]
        public async Task DeleteAccountAsync_NonExistingAccount_ReturnsFalse()
        {
            // Arrange
            var repository = new Repository();
            var user = await repository.AddUserAsync("TestUser");

            // Act
            var result = await repository.DeleteAccountAsync(user.UserId, 999);

            // Assert
            Assert.IsFalse(result);
        }

        [TestMethod]
        public async Task DepositAsync_ValidDeposit_ReturnsTrue()
        {
            // Arrange
            var repository = new Repository();
            var user = await repository.AddUserAsync("TestUser");
            var account = await repository.AddAccountAsync(user.UserId, 200);

            // Act
            var result = await repository.DepositAsync(account.AccountId, 50);

            // Assert
            Assert.IsTrue(result);
            Assert.AreEqual(250, account.Balance);
        }

        [TestMethod]
        public async Task DepositAsync_NegativeAmount_ThrowsArgumentException()
        {
            // Arrange
            var repository = new Repository();
            var user = await repository.AddUserAsync("TestUser");
            var account = await repository.AddAccountAsync(user.UserId, 200);

            // Act and Assert
            await Assert.ThrowsExceptionAsync<ArgumentException>(() => repository.DepositAsync(account.AccountId, -50));
        }

        [TestMethod]
        public async Task DepositAsync_AmountExceedsLimit_ReturnsFalse()
        {
            // Arrange
            var repository = new Repository();
            var user = await repository.AddUserAsync("TestUser");
            var account = await repository.AddAccountAsync(user.UserId, 200);

            // Act
            var result = await repository.DepositAsync(account.AccountId, 11000);

            // Assert
            Assert.IsFalse(result);
        }

        [TestMethod]
        public async Task WithdrawAsync_ValidWithdrawal_ReturnsTrue()
        {
            // Arrange
            var repository = new Repository();
            var user = await repository.AddUserAsync("TestUser");
            var account = await repository.AddAccountAsync(user.UserId, 200);

            // Act
            var result = await repository.WithdrawAsync(account.AccountId, 50);

            // Assert
            Assert.IsTrue(result);
            Assert.AreEqual(150, account.Balance);
        }

        [TestMethod]
        public async Task WithdrawAsync_NegativeAmount_ThrowsArgumentException()
        {
            // Arrange
            var repository = new Repository();
            var user = await repository.AddUserAsync("TestUser");
            var account = await repository.AddAccountAsync(user.UserId, 200);

            // Act and Assert
            await Assert.ThrowsExceptionAsync<ArgumentException>(() => repository.WithdrawAsync(account.AccountId, -50));
        }

        [TestMethod]
        public async Task WithdrawAsync_AmountExceedsBalance_ReturnsFalse()
        {
            // Arrange
            var repository = new Repository();
            var user = await repository.AddUserAsync("TestUser");
            var account = await repository.AddAccountAsync(user.UserId, 200);

            // Act
            var result = await repository.WithdrawAsync(account.AccountId, 300);

            // Assert
            Assert.IsFalse(result);
        }

        [TestMethod]
        public async Task WithdrawAsync_AmountExceedsLimit_ReturnsFalse()
        {
            // Arrange
            var repository = new Repository();
            var user = await repository.AddUserAsync("TestUser");
            var account = await repository.AddAccountAsync(user.UserId, 200);

            // Act
            var result = await repository.WithdrawAsync(account.AccountId, 180);

            // Assert
            Assert.IsFalse(result);
        }
    }
}