﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Banking_Application.Controllers;
using Banking_Application.Models;
using Banking_Application.Repositories;
using Microsoft.AspNetCore.Mvc;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
namespace Banking_Application_Tests
{
    [TestClass]
    public class UserControllerTests
    {
        [TestMethod]
        public async Task AddAccount_ValidAccount_ReturnsNewAccount()
        {
            // Arrange
            var repositoryMock = new Mock<IRepository>();
            var user = new UserModel { UserId = 1, UserName = "TestUser" };
            repositoryMock.Setup(r => r.GetUserAsync(1)).ReturnsAsync(user);
            repositoryMock.Setup(r => r.AddAccountAsync(1, 200)).ReturnsAsync(new AccountModel { AccountId = 1, Balance = 200 });
            var controller = new UserController(repositoryMock.Object);

            // Act
            var result = await controller.AddAccount(1, 200) as OkObjectResult;

            // Assert
            Assert.IsNotNull(result);
            var newAccount = result.Value as AccountModel;
            Assert.IsNotNull(newAccount);
            Assert.AreEqual(200, newAccount.Balance);
        }

        [TestMethod]
        public async Task AddAccount_InvalidInitialBalance_ReturnsBadRequest()
        {
            // Arrange
            var repositoryMock = new Mock<IRepository>();
            var user = new UserModel { UserId = 1, UserName = "TestUser" };
            repositoryMock.Setup(r => r.GetUserAsync(1)).ReturnsAsync(user);
            repositoryMock.Setup(r => r.AddAccountAsync(1, 50)).ThrowsAsync(new ArgumentException("Initial balance must be at least $100."));
            var controller = new UserController(repositoryMock.Object);

            // Act
            var result = await controller.AddAccount(1, 50) as BadRequestObjectResult;

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual("Bad Request: Initial balance must be at least $100.", result.Value);
        }

        [TestMethod]
        public async Task Deposit_ValidDeposit_ReturnsOk()
        {
            // Arrange
            var repositoryMock = new Mock<IRepository>();
            repositoryMock.Setup(r => r.DepositAsync(1, 50)).ReturnsAsync(true);
            var controller = new UserController(repositoryMock.Object);

            // Act
            var result = await controller.Deposit(1, 50) as OkObjectResult;

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual("Deposit successful.", result.Value);
        }

        [TestMethod]
        public async Task Deposit_NegativeAmount_ReturnsBadRequest()
        {
            // Arrange
            var repositoryMock = new Mock<IRepository>();
            repositoryMock.Setup(r => r.DepositAsync(1, -50)).ThrowsAsync(new ArgumentException("Deposit amount cannot be negative."));
            var controller = new UserController(repositoryMock.Object);

            // Act
            var result = await controller.Deposit(1, -50) as BadRequestObjectResult;

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual("Bad Request: Deposit amount cannot be negative.", result.Value);
        }

        [TestMethod]
        public async Task Deposit_AmountExceedsLimit_ReturnsBadRequest()
        {
            // Arrange
            var repositoryMock = new Mock<IRepository>();
            repositoryMock.Setup(r => r.DepositAsync(1, 11000)).ReturnsAsync(false);
            var controller = new UserController(repositoryMock.Object);

            // Act
            var result = await controller.Deposit(1, 11000) as BadRequestObjectResult;

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual("Deposit failed. Check if the amount is positive and does not exceed $10,000.", result.Value);
        }

        [TestMethod]
        public async Task Withdraw_ValidWithdrawal_ReturnsOk()
        {
            // Arrange
            var repositoryMock = new Mock<IRepository>();
            repositoryMock.Setup(r => r.WithdrawAsync(1, 50)).ReturnsAsync(true);
            var controller = new UserController(repositoryMock.Object);

            // Act
            var result = await controller.Withdraw(1, 50) as OkObjectResult;

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual("Withdrawal successful.", result.Value);
        }

        [TestMethod]
        public async Task Withdraw_NegativeAmount_ReturnsBadRequest()
        {
            // Arrange
            var repositoryMock = new Mock<IRepository>();
            repositoryMock.Setup(r => r.WithdrawAsync(1, -50)).ThrowsAsync(new ArgumentException("Withdrawal amount cannot be negative."));
            var controller = new UserController(repositoryMock.Object);

            // Act
            var result = await controller.Withdraw(1, -50) as BadRequestObjectResult;

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual("Bad Request: Withdrawal amount cannot be negative.", result.Value);
        }

        [TestMethod]
        public async Task Withdraw_AmountExceedsBalance_ReturnsBadRequest()
        {
            // Arrange
            var repositoryMock = new Mock<IRepository>();
            repositoryMock.Setup(r => r.WithdrawAsync(1, 300)).ReturnsAsync(false);
            var controller = new UserController(repositoryMock.Object);

            // Act
            var result = await controller.Withdraw(1, 300) as BadRequestObjectResult;

            // Assert
            Assert.IsNotNull(result);
            Assert.AreEqual("Withdrawal failed. Check if the amount is positive, does not exceed 90% of the account balance, and leaves at least $100 in the account.", result.Value);
        }
    }
}

