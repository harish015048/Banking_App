﻿namespace Banking_Application.Models
{
    public class AccountModel
    {
        public int AccountId { get; set; }
        public decimal Balance { get; set; }
    }
}
